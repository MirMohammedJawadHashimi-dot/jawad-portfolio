JAWAD HASHIMI — CREATIVE TECHNOLOGY PORTFOLIO

Open index.html in a browser, or use VS Code + Live Server.
Included: profile photo, complete 3-page CV, responsive portfolio, 3D-style CSS skill visuals, contact links, experience, education, Takhassus Yaab project concept, and placeholders for future certificates/design/video/web projects.
Future files can be placed in assets/ and referenced from index.html.
